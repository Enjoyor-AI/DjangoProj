IF_TEST = False
TD = 0
TA = 20
TW = 60
TRD = 20
TEST_DATE = '2018-11-22'
####################
TEST_DAY = '2018-11-22'
INTER_INF_IP = '33.83.100.145'