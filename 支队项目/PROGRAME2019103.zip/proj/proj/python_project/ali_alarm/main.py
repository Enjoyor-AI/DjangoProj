from .alarm_priority_algorithm1126 import alarm_data_regular_filter

def main():
    alarm_data_regular_filter.create_process()

if __name__ == '__main__':
    # from alarm_priority_algorithm2 import alarm_data_regular_filter
    # alarm_data_regular_filter.new_kde_cal()
    main()