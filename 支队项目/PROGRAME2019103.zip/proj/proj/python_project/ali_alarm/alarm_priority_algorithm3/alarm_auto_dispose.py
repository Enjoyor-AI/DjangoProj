from proj.python_project.ali_alarm.alarm_priority_algorithm3.alarm_data_regular_filter import new_kde_cal

import datetime as dt
from proj.config.database import Postgres
import logging

TEST = False
TIME_DELAY_N = 10
TIME_DELAY_W = 30
logger = logging.getLogger('schedulerTask')  # 获取settings.py配置文件中logger名称

class SqlContent:
    sql_get_operate_dispose = """
    SELECT
	distinct fat.inter_id,son.date_day+son.date_time,fat.reason_type,fat.alarm_id,son.disp_type,son.inter_name
FROM
	disposal_classify fat
RIGHT JOIN (
	SELECT
		inter_id,
		MAX (time_point) AS time_point 
	FROM
		disposal_classify
	where  inter_id in ({0}) and time_point > '{1}' and reason_type !=10
	GROUP BY
		inter_id
) grl
on
	fat.inter_id = grl.inter_id
AND fat.time_point = grl.time_point
LEFT JOIN disposal_data son on fat.alarm_id = son.alarm_id

"""
    sql_get_int_type = """
SELECT
	gaode_id,
	int_alarm_type,
	int_name
FROM
	alarm_int_alarm_type
WHERE
	gaode_id IN ({0})"""


class OperateAutoDis():
    # pg_inf = {'database': "research", 'user': "django", 'password': "postgres",
    #           'host': "33.83.100.144", 'port': "5432"}
    # pg_inf = {'database': "signal_specialist", 'user': "django", 'password': "postgres",
    #           'host': "192.168.20.46", 'port': "5432"}
    intid_list = ['14KC7097AL0', '14KOB0981K0']

    def __init__(self):
        self.pg = Postgres()
        self.int_auto = {}

    def get_int_type(self, intid_list=None):
        if TEST:
            intid_list = OperateAutoDis.intid_list
        str_intid_list = ['\'' + int + '\'' for int in intid_list]
        pram = ','.join(str_intid_list)
        # print(pram)
        result = self.pg.call_pg_data(SqlContent.sql_get_int_type.format(pram))
        print('get_int_type',result)
        return result

    def get_alarm_type(self, intid_list=None):
        if TEST:
            intid_list = OperateAutoDis.intid_list
        result = new_kde_cal()
        print(result)
        return result

    def get_alarm_operate_type(self, intid_list=None):
        if TEST:
            intid_list = OperateAutoDis.intid_list
        str_intid_list = ['\'' + int + '\'' for int in intid_list]
        pram = ','.join(str_intid_list)
        current_date = dt.datetime.now().date()
        stime = str(current_date) + ' 00:00:00'
        print(pram)
        result = self.pg.call_pg_data(SqlContent.sql_get_operate_dispose.format(pram,stime), fram=True)
        print('operate', result)
        return result

    def alarm_auto_set(self, alarm_dispose_data):
        auto = None
        for i in alarm_dispose_data:
            (int_id, time_point, auto_dis, alarm_id, dis_type, int_name) = i
            current_time = dt.datetime.now()
            time_delta = (current_time - dt.datetime.strptime(str(time_point), '%Y-%m-%d %H:%M:%S')).seconds
            current_time = dt.datetime.now()
            # 关注
            if dis_type == 1 and time_delta < 60 * TIME_DELAY_N:
                end_time = dt.datetime.strptime(str(time_point), '%Y-%m-%d %H:%M:%S') + dt.timedelta(
                    seconds=60 * TIME_DELAY_N)
                self.int_auto[int_id] = {'lastDis': '1', 'auto': 1, 'endTime': end_time}
                auto = True
            # 调控
            elif dis_type == 2 and time_delta < 60 * TIME_DELAY_N:
                end_time = dt.datetime.strptime(str(time_point), '%Y-%m-%d %H:%M:%S') + dt.timedelta(
                    seconds=60 * TIME_DELAY_N)
                self.int_auto[int_id] = {'lastDis': '2', 'auto': 1, 'endTime': end_time}
                auto = True
            # 误报
            elif dis_type == 3 and time_delta < 60 * TIME_DELAY_W:
                end_time = dt.datetime.strptime(str(time_point), '%Y-%m-%d %H:%M:%S') + dt.timedelta(
                    seconds=60 * TIME_DELAY_W)
                self.int_auto[int_id] = {'lastDis': '3', 'auto': 1, 'endTime': end_time}
                auto = True
            else:
                # 无处置记录
                end_time = current_time + dt.timedelta(
                    seconds=60 * TIME_DELAY_N)
                self.int_auto[int_id] = {'lastDis': '5', 'auto': 0, 'endTime': end_time}
                auto = False
        return auto

    def alarm_auto_judge(self, alarm_int_list):
        """
        :param alarm_int_list: 报警路口列表
        :return: 报警是否自动处置结果
        lastDis：上一次路口处置状态【1：关注；2：调控；3：误报；4：快处；5：推送人工】
        """
        reponse_all = []
        reponse = {'alarmInt': None, 'autoDis': None}
        int_key = self.int_auto.keys()
        int_check_state = []
        current_time = dt.datetime.now()
        for int in alarm_int_list:
            if int not in int_key:
                new_end_time = current_time + dt.timedelta(seconds=TIME_DELAY_N * 60)
                self.int_auto[int] = {'lastDis': '4', 'auto': 0, 'endTime': new_end_time}
                reponse = {'alarmInt': int, 'autoDis': True}
                reponse_all.append(reponse)
            else:
                int_auto_data = self.int_auto.get(int)
                last_dis = int_auto_data.get('lastDis')
                auto = int_auto_data.get('auto')
                end_time = int_auto_data.get('endTime')
                if current_time > end_time:
                    # 路口超时后，自动处置第一次报警！同时将路口状态设置为自动处置
                    new_end_time = current_time + dt.timedelta(seconds=TIME_DELAY_N * 60)
                    self.int_auto[int] = {'lastDis': '4', 'auto': 0, 'endTime': new_end_time}
                    reponse = {'alarmInt': int, 'autoDis': True}
                    reponse_all.append(reponse)

                elif (last_dis == '4' or last_dis == '5') and auto == 0 and current_time <= end_time:
                    # 规定时间间隔内，上一次处置为自动处置
                    # 1、判断路口类型；2、判断路口报警类型
                    int_check_state.append(int)
                    pass

                elif auto == 1 and current_time <= end_time:
                    # 路口被设置为自动处置，且未超时
                    reponse = {'alarmInt': int, 'autoDis': True}
                    reponse_all.append(reponse)
        if len(int_check_state) > 0:
            alarm_type = self.get_alarm_type()
            print('alarm_type', alarm_type)
            if alarm_type:
                fre_alarm_list = [i[0] for i in alarm_type if i[4] == '0' or i[4] == '0.0']
                print("常发报警路口", fre_alarm_list)
                int_type = self.get_int_type(int_check_state)
                frame_int_state = self.get_alarm_operate_type(int_check_state)
                for i in int_type:
                    int_id = i[0]
                    try:
                        match_alarm_type = frame_int_state[frame_int_state['inter_id'] == int_id].values
                    except Exception as e:
                        print(e)
                    else:
                        # 若路口匹配到了调控记录
                        auto = self.alarm_auto_set(match_alarm_type)
                        if auto is True:
                            reponse = {'alarmInt': int_id, 'autoDis': True}
                            reponse_all.append(reponse)
                        else:
                            # 报警较少路口
                            if i[1] == '0':
                                reponse = {'alarmInt': int_id, 'autoDis': False}
                                reponse_all.append(reponse)
                            # 报警较多路口
                            elif i[1] == '1':
                                if int_id in fre_alarm_list:
                                    reponse = {'alarmInt': int_id, 'autoDis': True}
                                    reponse_all.append(reponse)
                                else:
                                    reponse = {'alarmInt': int_id, 'autoDis': False}
                                    reponse_all.append(reponse)
            else:
                logger.warning("无法计算报警强度")
                for int in int_check_state:
                    reponse = {'alarmInt': int, 'autoDis': False}
                    reponse_all.append(reponse)
        else:
            pass
        return reponse_all


if __name__ == "__main__":
    O1 = OperateAutoDis()
    # O1.get_alarm_operate_type()
    result = O1.alarm_auto_judge(['14KC7097AL0', '14LMM097HE0'])
    result = O1.alarm_auto_judge(['14KC7097AL0', '14LMM097HE0'])
    print(result)
