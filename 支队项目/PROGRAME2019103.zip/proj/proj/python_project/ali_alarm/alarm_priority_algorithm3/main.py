from proj.python_project.ali_alarm.alarm_priority_algorithm3.alarm_data_regular_filter import create_process,new_kde_cal,his_model_update

if __name__ == '__main__':
    # his_model_update()
    result = new_kde_cal()
    print(result)