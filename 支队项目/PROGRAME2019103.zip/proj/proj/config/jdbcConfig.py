dataBase = "sms"
user = "postgres"
password = "postgres"
host = "33.83.100.145"
port = 5432