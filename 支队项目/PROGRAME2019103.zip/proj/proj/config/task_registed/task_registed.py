RegistedTask = {'TaskName': ['t1',],
                'Address': [r'..config\task_registed\t1.py',]}